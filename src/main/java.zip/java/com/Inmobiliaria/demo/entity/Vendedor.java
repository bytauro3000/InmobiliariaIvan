package com.Inmobiliaria.demo.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Inmobiliaria.demo.enums.Genero;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "vendedor")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Vendedor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_vendedor", unique = true, length = 7)
	private Integer idVendedor;


    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "apellidos", nullable = false, length = 100)
    private String apellidos;

    @Column(name = "dni", nullable = false, unique = true, length = 20)
    private String dni;

    @Column(name = "celular", length = 20)
    private String celular;

    @Column(name = "email", length = 100)
    private String email;

    @Column(name = "direccion", length = 150)
    private String direccion;

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "genero", length = 10, nullable = false)
    private Genero genero;
    
    @Column(name = "comision", precision = 5, scale = 2)
    private BigDecimal comision = BigDecimal.ZERO;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_distrito")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Distrito distrito;

    // Cuenta de usuario asociada (opcional). Solo los vendedores que necesitan
    // entrar al sistema tienen cuenta; los demás quedan con null (históricos).
    // Se ignora en la serialización JSON para evitar errores de lazy/serialización
    // en listados (la lista de vendedores y el select de contrato no la necesitan).
    // El vínculo se resuelve por repositorio (findByIdUsuario), no por el JSON.
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;
}
