package com.Inmobiliaria.demo.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import com.Inmobiliaria.demo.dto.ContratoRequestDTO;
import com.Inmobiliaria.demo.dto.ContratoResponseDTO;
import com.Inmobiliaria.demo.dto.ContratoListItemDTO;
import com.Inmobiliaria.demo.dto.LotesVendidosResponseDTO;
import com.Inmobiliaria.demo.dto.TransferenciaResponseDTO;
import com.Inmobiliaria.demo.service.ContratoService;

import lombok.RequiredArgsConstructor;

import com.Inmobiliaria.demo.scheduler.ContratoEstadoScheduler;

@RestController
@RequestMapping("/api/contratos")
@RequiredArgsConstructor
public class ContratoController {

    private final ContratoService contratoService;
    private final ContratoEstadoScheduler contratoEstadoScheduler;

    @PostMapping("/agregar")
    public ResponseEntity<ContratoResponseDTO> guardarContrato(
        @Valid @RequestBody ContratoRequestDTO requestDTO,
        Principal principal
    ) {
        ContratoResponseDTO contratoGuardado = contratoService.guardarContrato(requestDTO, principal);
        return new ResponseEntity<>(contratoGuardado, HttpStatus.CREATED);
    }

    @PutMapping("/actualizar/{id}")
    public ResponseEntity<ContratoResponseDTO> actualizarContrato(
        @PathVariable Integer id,
        @Valid @RequestBody ContratoRequestDTO requestDTO
    ) {
        ContratoResponseDTO actualizado = contratoService.actualizarContrato(id, requestDTO);
        return new ResponseEntity<>(actualizado, HttpStatus.OK);
    }

    @GetMapping("/listar")
    public List<ContratoResponseDTO> listarContratos() {
        return contratoService.listarContratos();
    }

    @GetMapping("/listar-resumen")
    public ResponseEntity<?> listarContratosResumen(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false, defaultValue = "50") Integer size) {
        if (page != null) {
            return ResponseEntity.ok(contratoService.listarContratosResumenPaginado(PageRequest.of(page, size)));
        }
        return ResponseEntity.ok(contratoService.listarContratosResumen());
    }

    // Buscar contrato por ID del contrato
    @GetMapping("/{id}")
    public ResponseEntity<ContratoResponseDTO> buscarContratoPorId(@PathVariable Integer id) {
        ContratoResponseDTO contrato = contratoService.buscarPorId(id);
        if (contrato != null) {
            return new ResponseEntity<>(contrato, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Buscar contrato por PROGRAMA-MZ-LT
    @GetMapping("/buscar-por-lote")
    public ResponseEntity<ContratoResponseDTO> buscarPorLote(
            @RequestParam Integer idPrograma,
            @RequestParam String manzana,
            @RequestParam String numeroLote) {
        ContratoResponseDTO contrato = contratoService.buscarPorProgramaManzanaLote(idPrograma, manzana, numeroLote);
        return ResponseEntity.ok(contrato);
    }

    @GetMapping("/buscar-por-cliente")
    public List<ContratoResponseDTO> buscarPorCliente(@RequestParam String termino) {
        return contratoService.buscarPorNombreCliente(termino);
    }

    @GetMapping("/buscar-por-cliente-resumen")
    public List<ContratoListItemDTO> buscarPorClienteResumen(@RequestParam String termino) {
        return contratoService.buscarPorNombreClienteResumen(termino);
    }

    // Lotes vendidos (agrupados por programa). Filtro opcional por idVendedor.
    @GetMapping("/lotes-vendidos")
    public LotesVendidosResponseDTO listarLotesVendidos(
            @RequestParam(value = "idVendedor", required = false) Integer idVendedor) {
        return contratoService.listarLotesVendidos(idVendedor);
    }

    @DeleteMapping("/eliminar/{id}")
    public void eliminarContrato(@PathVariable Integer id) {
        contratoService.eliminarContrato(id);
    }

    
    @GetMapping("/{id}/impacto-edicion")
    public ResponseEntity<Map<String, Object>> consultarImpactoEdicion(@PathVariable Integer id) {
        return ResponseEntity.ok(contratoService.consultarImpactoEdicion(id));
    }

    @PatchMapping("/{id}/estado")
    public ResponseEntity<ContratoResponseDTO> cambiarEstado(
            @PathVariable Integer id,
            @RequestParam String estado) {
        ContratoResponseDTO actualizado = contratoService.cambiarEstado(id, estado);
        return ResponseEntity.ok(actualizado);
    }

    @PatchMapping("/{id}/renuncia")
    public ResponseEntity<ContratoResponseDTO> registrarRenuncia(@PathVariable Integer id) {
        ContratoResponseDTO resultado = contratoService.registrarRenuncia(id);
        return ResponseEntity.ok(resultado);
    }

    @PatchMapping("/{id}/transferencia")
    public ResponseEntity<TransferenciaResponseDTO> registrarTransferencia(@PathVariable Integer id) {
        TransferenciaResponseDTO datos = contratoService.registrarTransferencia(id);
        return ResponseEntity.ok(datos);
    }

    @GetMapping("/{id}/imprimir")
    public ResponseEntity<byte[]> descargarContratoPdf(@PathVariable Integer id) {
        byte[] pdfBytes = contratoService.generarPdf(id);
        return ResponseEntity.ok()
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=Contrato_LaFlorida_" + id + ".pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }

    @PostMapping(value = "/{id}/voucher-inicial", consumes = "multipart/form-data")
    public ResponseEntity<ContratoResponseDTO> subirVoucherInicial(
            @PathVariable Integer id,
            @RequestParam("voucher") org.springframework.web.multipart.MultipartFile voucher) {
        ContratoResponseDTO dto = contratoService.subirVoucherInicial(id, voucher);
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/scheduler/ejecutar")
    public ResponseEntity<String> ejecutarScheduler() {
        contratoEstadoScheduler.ejecutarManualmente();
        return ResponseEntity.ok("Scheduler ejecutado. Revisa los logs de Spring Boot.");
    }

    // ── Lista de contratos por programa y estado ─────────────────────────────

    @GetMapping("/lista-programa")
    public ResponseEntity<List<com.Inmobiliaria.demo.dto.ListaContratoDTO>> listaContratos(
            @RequestParam(required = false) Integer idPrograma,
            @RequestParam(required = false) List<String> estados) {
        List<com.Inmobiliaria.demo.dto.ListaContratoDTO> lista =
                contratoService.listarContratosPorProgramaYEstado(idPrograma, estados);
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/lista-programa/excel")
    public ResponseEntity<byte[]> listaContratosExcel(
            @RequestParam(required = false) Integer idPrograma,
            @RequestParam(required = false) List<String> estados) {
        try {
            List<com.Inmobiliaria.demo.dto.ListaContratoDTO> lista =
                    contratoService.listarContratosPorProgramaYEstado(idPrograma, estados);
            byte[] excelBytes = com.Inmobiliaria.demo.util.ListaContratosExcel.generar(lista);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=Lista_Contratos.xlsx")
                    .contentType(org.springframework.http.MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(excelBytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/lista-programa/word")
    public ResponseEntity<byte[]> listaContratosWord(
            @RequestParam(required = false) Integer idPrograma,
            @RequestParam(required = false) List<String> estados) {
        try {
            List<com.Inmobiliaria.demo.dto.ListaContratoDTO> lista =
                    contratoService.listarContratosPorProgramaYEstado(idPrograma, estados);
            byte[] wordBytes = com.Inmobiliaria.demo.util.ListaContratosWord.generar(lista);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=Lista_Contratos.docx")
                    .contentType(org.springframework.http.MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                    .body(wordBytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/lista-programa/pdf")
    public ResponseEntity<byte[]> listaContratosPdf(
            @RequestParam(required = false) Integer idPrograma,
            @RequestParam(required = false) List<String> estados) {
        try {
            List<com.Inmobiliaria.demo.dto.ListaContratoDTO> lista =
                    contratoService.listarContratosPorProgramaYEstado(idPrograma, estados);
            byte[] pdfBytes = com.Inmobiliaria.demo.util.ReporteListaContratosPdf.generar(lista);
            return ResponseEntity.ok()
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=Lista_Contratos.pdf")
                    .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}