package com.Inmobiliaria.demo.scheduler;

import com.Inmobiliaria.demo.entity.Comprobante;
import com.Inmobiliaria.demo.entity.ContratoCliente;
import com.Inmobiliaria.demo.entity.PagoLetras;
import com.Inmobiliaria.demo.repository.ComprobanteRepository;
import com.Inmobiliaria.demo.repository.PagoLetraRepository;
import com.Inmobiliaria.demo.service.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;


@Slf4j
@Component
@RequiredArgsConstructor
public class ComprobanteEmailScheduler {

    private final ComprobanteEmailHelper helper;
    private final AtomicBoolean ejecutando = new AtomicBoolean(false);

    // Ejecutar cada día a las 10:00 AM hora Lima
    @Scheduled(cron = "0 0 10 * * *", zone = "America/Lima")
    public void enviarPorCron() {
        log.info(">>> ComprobanteEmailScheduler: enviando comprobantes por cron diario...");
        if (!ejecutando.compareAndSet(false, true)) {
            log.warn(">>> ComprobanteEmailScheduler: ya hay un envío en curso, se omite.");
            return;
        }
        try {
            helper.enviarComprobantesDelDiaAnterior(ejecutando);
        } finally {
            ejecutando.set(false);
        }
    }

    @Slf4j
    @Service
    @RequiredArgsConstructor
    public static class ComprobanteEmailHelper {

        private final PagoLetraRepository    pagoLetraRepository;
        private final ComprobanteRepository  comprobanteRepository;
        private final EmailService           emailService;

        @Transactional
        public void enviarComprobantesDelDiaAnterior(AtomicBoolean ejecutando) {
            try {
                LocalDate ayer = LocalDate.now().minusDays(1);

                // Solo traer pagos que AÚN NO tuvieron email enviado
                List<PagoLetras> pagos = pagoLetraRepository.findByFechaPagoAndEmailEnviadoFalse(ayer);

                if (pagos.isEmpty()) {
                    log.info(">>> ComprobanteEmailScheduler: no hay pagos pendientes de envío del {}.", ayer);
                    return;
                }

                log.info(">>> ComprobanteEmailScheduler: {} pago(s) del {} pendientes de envío.", pagos.size(), ayer);

                // ── Agrupar por número de comprobante usando la relación centralizada ──
                // Se lee desde pago.getComprobante().getNumeroCompleto() en lugar del
                // campo propio que ya fue eliminado de PagoLetras.
                Map<String, List<PagoLetras>> grupos = new LinkedHashMap<>();
                for (PagoLetras pago : pagos) {
                    Comprobante comp = pago.getComprobante();
                    String clave = (comp != null && comp.getNumeroCompleto() != null && !comp.getNumeroCompleto().isBlank())
                            ? comp.getNumeroCompleto()
                            : "SIN_COMP_" + pago.getIdPago();
                    grupos.computeIfAbsent(clave, k -> new ArrayList<>()).add(pago);
                }

                int grupos_enviados = 0;
                int grupos_sin_email = 0;

                for (Map.Entry<String, List<PagoLetras>> entry : grupos.entrySet()) {
                    List<PagoLetras> grupo = entry.getValue();
                    PagoLetras primero = grupo.get(0);

                    try {
                        // Obtener todos los emails únicos de los clientes del contrato
                        var contrato = primero.getLetra().getContrato();
                        List<String> emails = new ArrayList<>();

                        if (contrato.getClientes() != null) {
                            for (ContratoCliente cc : contrato.getClientes()) {
                                String email = cc.getCliente().getEmail();
                                if (email != null && !email.isBlank() && !emails.contains(email)) {
                                    emails.add(email);
                                }
                            }
                        }

                        if (emails.isEmpty()) {
                            log.warn("Contrato #{} sin emails — comprobante {} omitido.",
                                    contrato.getIdContrato(), entry.getKey());
                            grupos_sin_email++;
                            // Marcar el comprobante como enviado para no reintentar indefinidamente
                            // FIX: usar UPDATE directo para no reescribir fechaEmision via dirty-checking
                            grupo.stream()
                                 .map(PagoLetras::getComprobante)
                                 .filter(Objects::nonNull)
                                 .forEach(comp -> comprobanteRepository.marcarEmailEnviado(comp.getIdComprobante()));
                            continue;
                        }

                        // ── MODO PRUEBA ──────────────────────────────────────────────────────
                        // Solo se envía al correo de prueba. Para producción:
                        // 1. Elimina las dos líneas siguientes
                        // 2. Descomenta: log.info("Enviando comprobante {} a: {}", ...)
                        List<String> emailsDestino = List.of("bytauro3000@gmail.com");
                        log.info("MODO PRUEBA — comprobante {} redirigido a: {} (originales: {})",
                                entry.getKey(), emailsDestino, emails);
                        // ── FIN MODO PRUEBA ──────────────────────────────────────────────────
                        // List<String> emailsDestino = emails;
                        // log.info("Enviando comprobante {} a: {}", entry.getKey(), emails);

                        emailService.enviarComprobanteATodos(grupo, emailsDestino);

                        // Marcar el comprobante como enviado (fuente de verdad unificada)
                        // FIX: usar UPDATE directo para no reescribir fechaEmision via dirty-checking
                        grupo.stream()
                             .map(PagoLetras::getComprobante)
                             .filter(Objects::nonNull)
                             .forEach(comp -> comprobanteRepository.marcarEmailEnviado(comp.getIdComprobante()));
                        grupos_enviados++;

                    } catch (Exception e) {
                        log.error("Error procesando comprobante {}: {}", entry.getKey(), e.getMessage());
                    }
                }

                log.info(">>> ComprobanteEmailScheduler: {} grupo(s) enviado(s), {} sin email.",
                        grupos_enviados, grupos_sin_email);

            } finally {
                ejecutando.set(false);
            }
        }
    }
}