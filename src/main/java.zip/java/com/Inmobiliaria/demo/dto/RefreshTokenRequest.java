package com.Inmobiliaria.demo.dto;

import lombok.Data;

@Data
public class RefreshTokenRequest {
    private String refreshToken;
}
