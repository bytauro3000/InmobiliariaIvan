package com.Inmobiliaria.demo.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmpresaRequestDTO {
    private String nombreLegal;
    private String nombreComercial;
    private String ruc;
    private String direccion;
    private String telefono;
    private String celular;
    private String email;
    private String logoUrl;
    private String logoSmallUrl;
    private String paginaWeb;
    private String representanteLegal;
    private String representanteDni;
    private String partidaElectronica;
    private String ubigeo;
    private String distrito;
    private String provincia;
    private String departamento;
    private String tipoCalculoMora;
    private BigDecimal moraPorcentaje;
    private BigDecimal moraMontoDiario;
    private BigDecimal moraTasaDiaria;

    private String notificacionEmail;
}
