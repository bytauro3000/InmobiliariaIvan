package com.Inmobiliaria.demo.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "pago_letra")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PagoLetras extends PagoBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago")
    private Integer idPago;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_letra", nullable = false)
    private LetraCambio letra;
}