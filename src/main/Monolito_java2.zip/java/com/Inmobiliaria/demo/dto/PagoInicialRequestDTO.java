package com.Inmobiliaria.demo.dto;

import com.Inmobiliaria.demo.enums.MedioPago;
import com.Inmobiliaria.demo.enums.TipoComprobante;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PagoInicialRequestDTO {

    private Double importePagado;
    private String fechaPago;
    private MedioPago medioPago;
    private String numeroOperacion;
    private String observaciones;
    private TipoComprobante tipoComprobante;
    private String numeroComprobantePersonalizado;
}