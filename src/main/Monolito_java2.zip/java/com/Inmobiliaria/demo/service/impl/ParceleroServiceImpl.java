package com.Inmobiliaria.demo.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.Inmobiliaria.demo.entity.Parcelero;
import com.Inmobiliaria.demo.repository.ParceleroRepository;
import com.Inmobiliaria.demo.exception.NegocioException;
import com.Inmobiliaria.demo.service.ParceleroService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor 
public class ParceleroServiceImpl implements ParceleroService {

    
    private final ParceleroRepository parceleroRepository;

    @Override
    public List<Parcelero> listarParceleros() {
        return parceleroRepository.findAll();
    }

    @Override
    public Optional<Parcelero> obtenerParceleroPorId(Integer id) {
        return parceleroRepository.findById(id);
    }

    @Override
    public Parcelero guardarParcelero(Parcelero parcelero) {
        return parceleroRepository.save(parcelero);
    }

    @Override
    public Parcelero actualizarParcelero(Integer id, Parcelero parcelero) {
        return parceleroRepository.findById(id)
                .map(p -> {
                    p.setNombres(parcelero.getNombres());
                    p.setApellidos(parcelero.getApellidos());
                    p.setDni(parcelero.getDni());
                    p.setCelular(parcelero.getCelular());
                    p.setDireccion(parcelero.getDireccion());
                    p.setEmail(parcelero.getEmail());
                    p.setDistrito(parcelero.getDistrito());
                    return parceleroRepository.save(p);
                })
                .orElseThrow(() -> new NegocioException("Parcelero no encontrado con id " + id));
    }

    @Override
    public void eliminarParcelero(Integer id) {
        parceleroRepository.deleteById(id);
    }
}