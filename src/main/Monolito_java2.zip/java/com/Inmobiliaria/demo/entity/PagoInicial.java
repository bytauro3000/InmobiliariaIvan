package com.Inmobiliaria.demo.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Inmobiliaria.demo.enums.MedioPago;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "pago_inicial")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PagoInicial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pago_inicial")
    private Integer idPagoInicial;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_contrato", nullable = false)
    private Contrato contrato;

    @Column(name = "importe_pagado", precision = 12, scale = 2, nullable = false)
    private BigDecimal importePagado;

    @Column(name = "fecha_pago", nullable = false)
    private LocalDate fechaPago;

    @Enumerated(EnumType.STRING)
    @Column(name = "medio_pago", length = 20)
    private MedioPago medioPago;

    @Column(name = "numero_operacion", length = 50)
    private String numeroOperacion;

    @Column(name = "observaciones", length = 255)
    private String observaciones;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_comprobante")
    private Comprobante comprobante;
}